import React, { useState } from 'react';

function App() {
  const [fileContent, setFileContent] = useState('');

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.onload = (e) => {
      setFileContent(e.target.result);
    };
    reader.readAsText(file);
  };

  return (
    <div className="App">
      <h1>Upload a Text File</h1>
      <form>
        <input type="file" accept=".txt" onChange={handleFileChange} />
      </form>
      <h2>File Content</h2>
      <pre>{fileContent}</pre>
    </div>
  );
}

export default App;


