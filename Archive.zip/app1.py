from flask import Flask, request, jsonify
import os
import pandas as pd

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify(message='No file part'), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify(message='No selected file'), 400
    if file:
        filename = file.filename
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        # Parse the CSV file
        try:
            df = pd.read_csv(filepath)
            parsed_data = df.to_dict(orient='records')
            return jsonify(message='File successfully uploaded and parsed', parsed_data=parsed_data)
        except Exception as e:
            return jsonify(message=f'File upload failed: {str(e)}'), 500

if __name__ == '__main__':
    app.run(debug=True)
